// let heure;
// let minute;
// let seconde;
// let valeurModifier;
// let bouton = document.getElementById('button');
// let message = document.getElementById('message');

// function afficherHeure(){
//     heure = parseInt(document.getElementById('valeur-heure').value);
//     minute = parseInt(document.getElementById('valeur-minute').value);
//     seconde = parseInt(document.getElementById('valeur-seconde').value);
//    seconde=seconde+1;
//    if(seconde==60) {
//        seconde="00";
//        minute=minute+1;
   
//    if(minute>59){
//        minute="00";
//        heure=heure+1;
   
//    if(heure>23){
//        heure="00";
//    }}}
//  valeurModifier= heure + "h" + minute + "min" + seconde + "sec";
//    message.innerHTML = valeurModifier;
// }
// bouton.addEventListener('click',afficherHeure,false);
const randomNumber = Math.random(); // crée un nombre aléatoire sur l'intervalle [0, 1]
const roundMeDown = Math.floor(495.966); // arrondit vers le bas à l'entier le plus proche, renvoie 495