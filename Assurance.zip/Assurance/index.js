
//Récupérer la div message avec son id dans mon html pour afficher le résultat aprés 
let message = document.getElementById('message');


//Récupérer l'id du bouton pour l'utilisé aprés avec la fonction
let button=document.getElementById('button');


//déclarer une variable compteur pour l'utilisé dans switch
let compteurPrime;


let diffage ;







function afficherResultat(){
    
    //déclarer une variable qui signifie le nombre de sinistres comise par le conducteur que je récupére dans
    //  mon DOM avec son id et sa valeur qui varie en fonction de l'utilisateur avec .value
    let accident = document.getElementById('accident').value;


    //déclarer une variable qui signifie l'âge du conducteur que je récupére dans mon DOM avec son
    //  id "age-conducteur" et sa valeur qui varie en fonction de l'utilisateur avec .value
    let ageConducteur = document.getElementById('age-conducteur').value;
    
    
    //je récupére dans mon DOM avec les années de permis du client grâce à son id "permis" et sa valeur
    //  qui varie en fonction de l'utilisateur avec .value
    let permis = document.getElementById('permis').value;
    
    
    
    
    //je récupére dans mon DOM avec les années de fidélité chez l'assurance grâce à son id "fidelite" 
    // et sa valeur qui varie en fonction de l'utilisateur avec .value
    let fidelite = document.getElementById('fidelite').value;


    //initialisé le compteur a zéro (notre référence de base)
    compteurPrime= 0;

    //je déclare une variable que je lui affecte la soustraction de l'âge du client moins 18ans pour 
    // l'utilisé dans les conditions logiques plutard
    diffage = ageConducteur - 18 ;
    
    
    
    
    
    //mettre des conditions logiques dés le départ pour vérifier si le client est apte a être assurer 
    if(accident > 3 ){
        //première condition si il a plus de 3 sinistres il est refusé
        message.innerHTML='<div class="alert alert-dark" role="alert">Refusé</div>'
    }else if(ageConducteur<18){
        //deuxième condition si le client n'est pas majeur il est refusé 
        message.innerHTML='<div class="alert alert-dark" role="alert">Refusé</div>'
    }else if(fidelite>permis ){
        //troisième condition si les années de fidélités sont supérieur aux années de permis il est refusé
        message.innerHTML='<div class="alert alert-dark" role="alert">Refusé</div>'
    }else if(diffage<permis ){
        //quatrième conditionsi difference d'âge est inferieur aux années de permis il set refusé 
        message.innerHTML='<div class="alert alert-dark" role="alert">Refusé</div>'
    
    //commencer a tester les différentes aquis du client qui impact les tarifs
    }else{
        if(ageConducteur > 25){
            compteurPrime = compteurPrime + 1;
            //si le client est plus âgé que 25ans il gagne un point
        }
        if (permis > 2){
            compteurPrime = compteurPrime + 1 ;
            //si le client posséde un permis plus de deux ans gagne un point 
        }
        if (fidelite > 1){
            compteurPrime = compteurPrime + 1 ;
            //si le client a plus d'un an de fidelité il gagne un point 
        }
        compteurPrime = compteurPrime - accident;
        // console.log(compteurPrime);
       //et tout a la fin on fais la soustraction de notre compteur et le nombre d'accidents 
       
       
       
        switch(compteurPrime){
            case 3: message.innerHTML = '<div class="alert alert-primary" role="alert">Bleu</div>'
            break;
            case 2: message.innerHTML = '<div class="alert alert-success" role="alert">Vert</div>'
            break;
            case 1: message.innerHTML = '<div class="alert alert-warning" role="alert">Orange</div>'
            break;
            case 0: message.innerHTML = '<div class="alert alert-danger" role="alert">Rouge</div>'
            break;
            case -1: message.innerHTML = '<div class="alert alert-dark" role="alert">Refusé</div>'
            break;
            default: message.innerHTML = '<div class="alert alert-dark" role="alert">Refusé</div>'
        }
    }
    }




    button.addEventListener('click', afficherResultat,false);