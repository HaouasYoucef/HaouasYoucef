

            let motSecret;

            let now=new Date(); // date du jour
            let tableauMot= new Array();
            let mots=new Array();
            
            let tailleMot;
            let coupsManques=0;
            let lettresTrouvees=0;
            let fini=false;
            
            mots[0]="JAVASCRIPT";
            mots[1]="VIRUS";
            mots[2]="RADIATEUR";
            mots[3]="POMPIER";
            mots[4]="VELO";
            mots[5]="HORLOGE";
            mots[6]="ELEPHANT";
            mots[7]="PANDA";
            mots[8]="CAMION";
            mots[9]="NAVIRE";
            mots[10]="TIGRE";
            mots[11]="POLICE";
            mots[12]="LENOVO";
            
            //On prend un mot au hasard en fonction de la seconde en cours
            motSecret=mots[now.getSeconds()%mots.length];
            tailleMot=motSecret.length;
            
            //Permet de changer la couleur des touches du clavier
            function changeCouleur(element, couleur){
                element.style.backgroundColor=couleur;
            }
            //Gere les traitements à faire lorsqu'on appuie sur une touche
            function proposer(element){
               
                if(element.style.backgroundColor=="lightGreen" ||fini) return;
                //on recupère la lettre du clavier et on met la touche en lightGreen
                let lettre=element.innerHTML;
                changeCouleur(element,"lightGreen");
            
                let trouve=false;
                for (let i=0; i<tailleMot; i++){
            
                    if(tableauMot[i].innerHTML==lettre){
                        tableauMot[i].style.visibility='visible'; //on affiche la lettre
                        trouve=true;
                        lettresTrouvees++;
                    }
                }
                if (!trouve){
                    coupsManques++;
                    document.images['pendu'].src="images/pendu_"+coupsManques+".png";//on change l'image du pendu
            
                    //Si on a raté 9 fois:
                    if(coupsManques==9){
                        alert("Vous avez perdu !");
                        for(let i=0; i<tailleMot; i++) tableauMot[i].style.visibility='visible';
                        fini=true;
                        //on affiche le mot, on fini le jeu
                     }
                }
                if(lettresTrouvees==tailleMot){
                    alert("Bravo ! Vous avez découvert le mot secret!");
                    fini=true;
                     }
                }